//
//  TableViewCell.swift
//  Homework
//
//  Created by charles on 2018/7/1.
//  Copyright © 2018年 lizhonghuan. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
